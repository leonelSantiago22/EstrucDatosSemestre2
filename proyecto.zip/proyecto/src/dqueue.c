#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include "../include/queue.h"
Queue *front = NULL;
Queue *rear = NULL;
Queue *atras = NULL;
//Queue *adelante =NULL;
int cqueue=1;

void dequeue()//Borar elemento
{
    if (front==NULL)
    {
        printf("\n\nqueue in empty\n");
    }else
    {
        Queue *temp;
        temp = front;
        front = front->next;
        printf("\n\n%s eliminado", temp->data);
        free(temp);
    }
}

void miqueue()//Mostrar primer elemento
{
    if (front==NULL)
    {
        printf("\n\nqueue in empty\n");
    }else
    {
        Queue *temp;
        temp = front;
        printf("\n\n%s", temp->data);
    }
}

void display()//Mostrar todos los elementos
{
    int i=1;
    Queue *temp;
    temp = front;
    printf("\nPaginas Visitadas: \n");
    while (temp!=NULL)
    {
        printf("\n%d %s \t ",i, temp->data);
        temp = temp->next;
        i++;
    }
}
int x=1;

void atras_()
{
    Queue *temp;
    temp = rear;
    printf("\nPaginas Visitada anterior: \n");
    temp = temp->back;
    if (temp!=NULL)
    {
        printf("\n %s \t ", temp->data);
    }
    
}

void equeuue(char *item)//Ingresar los datos
{
  
     Queue *nptr =(Queue *) malloc(sizeof(Queue));
     Manejo = (Queue *) malloc(sizeof(item)+1*sizeof(char));
     nptr->data = item;
     nptr->next = NULL;
     nptr->back = NULL;
     cqueue++;
     if (rear == NULL)
     {
         front = nptr;
         rear = nptr;
     }else
     {
         rear->next = nptr;
         rear = rear->next;
     } 
    nptr = rear;
    printf("\nPagina Vistada %s", nptr->data);
}