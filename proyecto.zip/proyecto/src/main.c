#include <stdlib.h> 
#include <stdio.h>
#include "../include/queue.h"

int main()
{
    int  ch;
    int i=0;
    char *n;
    char ingresar[100][40];
    do
    {
        printf("\n\nQueue Menu");
        printf("\n1.-Visitar Pagina ");
        printf("\n2.-Eliminar Datos ");
        printf("\n3.-Mostrar Datos ");
        printf("\n4.-Mirar Primera pagina visitada ");
        printf("\n5.-atras ");
        printf("\n6.-Salir");
        printf("\ningresa una opcion 1-5? \n:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1: printf("\nIngresa una pagina web: \t"); 
                scanf("%s", ingresar[i]);
                n=ingresar[i];
                equeuue(n);
                i++;
                break;
        case 2: dequeue(); break;
        case 3: display(); break;
        case 4: miqueue(); break;
        case 5: atras_(); break;
        case 6: exit(-1); 
        default:
            break;
        }
    } while (ch !=0);
}