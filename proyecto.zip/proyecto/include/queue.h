struct queue
{
    char *data;
    //char array[40];
    struct queue *next;
    struct queue *back;
};
struct manejo
{
    char *datos;
};

struct queue *Manejo;
typedef struct manejo Manejos;
typedef struct queue Queue;
void dequeue();
void display();
void equeuue(char *item);
void miqueue();
void atras_();